Simple library for the TSL45315 Lux Sensor breakout board for Arduino.

- Initializes the sensor and puts it into "Normal Operation" mode.
- Read current lux value.

A simple demo sketch is in the TSL45315_example folder
